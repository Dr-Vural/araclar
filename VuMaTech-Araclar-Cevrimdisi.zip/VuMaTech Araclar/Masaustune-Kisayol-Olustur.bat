@echo off
setlocal
set "HEDEF=%~dp0BASLAT.html"
set "KS=%USERPROFILE%\Desktop\VuMaTech Araclar.url"
(
echo [InternetShortcut]
echo URL=file:///%HEDEF:\=/%
echo IconIndex=0
) > "%KS%"
echo Masaustune kisayol olusturuldu.
pause
