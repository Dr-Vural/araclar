#!/bin/bash
DIZIN="$(cd "$(dirname "$0")" && pwd)"
if command -v open >/dev/null 2>&1; then open "$DIZIN/BASLAT.html"
elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$DIZIN/BASLAT.html"
else echo "BASLAT.html dosyasini tarayicinizla acin"; fi
