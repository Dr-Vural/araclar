@echo off
start "" "%~dp0BASLAT.html"
